<br/>
<div align="center">

# TikTok Share Botter
Fastest multi-threaded and proxyless TikTok Share Botter to increase share count on videos. Click <a href="https://github.com/useragents/TikTok-Share-Botter/issues">here</a> to report bugs.
  
![image](https://user-images.githubusercontent.com/103281345/164895080-0a78e242-291d-4540-a503-90e6dc3954d3.png)
  
</div>

--------------------------------------

### Usage


1. Download ZIP <a href="https://github.com/useragents/TikTok-Share-Botter/archive/refs/heads/main.zip">here</a> and extract the ZIP
2. Install <a href="https://github.com/useragents/TikTok-Share-Botter/blob/main/requirements.txt">requirements.txt</a> by typing `pip install -r requirements.txt` in Command Prompt
4. Run the `main.py` script and enter your TikTok URL link and your threads amount.

### Please note

I am not responsible for your actions using this script.

For help ; piercer#0001
